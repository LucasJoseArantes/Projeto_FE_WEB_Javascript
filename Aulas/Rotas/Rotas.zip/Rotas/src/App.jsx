import { useState } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Index from './components/index'
import Menu from './components/menu'
import Sobrenos from './components/sobrenos'
import Contato from './components/contato'

function App() {

  return (
    <div>
      <Menu></Menu>
      <BrowserRouter>
      <Routes>
        <Route path="/" element={ <Index/>}></Route>
        <Route path="/contato" element={ <Contato/>}></Route>
        <Route path="/sobrenos" element={ <Sobrenos/> }></Route>
      </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App
