import React from 'react';
import styles from './Contato.module.css';
	
function Contato () {
	return (
		<div>
			<h2>Contato</h2>
			<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure architecto non nulla velit eius molestiae, dicta veniam cum illo rerum minima vitae natus voluptatibus maiores aliquam nesciunt omnis id consequuntur?</p>
		</div>
	);
}

export default Contato;