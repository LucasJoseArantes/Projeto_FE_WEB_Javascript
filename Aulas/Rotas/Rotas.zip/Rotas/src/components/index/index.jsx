const Index = () => {
    return <div>
        <h1>Teste</h1>
    </div>;
}

export default Index;