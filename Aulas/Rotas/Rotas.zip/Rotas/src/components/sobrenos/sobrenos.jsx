import css from './sobrenos.module.css'
const sobrenos = () => {
	return <div>sobrenos</div>;
}
export default sobrenos;